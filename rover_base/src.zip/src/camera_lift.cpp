/**
 * @file camera_lift_node.cpp
 * @brief ROS 2 node for controlling a camera lift mechanism via CAN bus.
 *
 * This node provides both action and topic interfaces to command the camera lift
 * to a specific height. It communicates with the hardware using CAN messages.
 * It also handles feedback from the hardware to monitor the current height
 */

#include "motion_base/camera_lift_node.hpp"
#include <cmath>

/**
 * @class CameraLiftNode
 * @brief Main ROS 2 node for controlling the camera lift.
 *
 * This node handles action goals and topic commands to move the camera lift,
 * sends CAN commands, receives feedback, and manages goal states.
 */
CameraLiftNode::CameraLiftNode() : Node("rover_camera_lift")
{
    // Declare, load, and validate parameters
    declareParameters();
    loadParameters();
    validateParameters();

    RCLCPP_INFO(this->get_logger(), "Parameter 'height_tolerance' FOR CAMERA : %f", tolerance_);

    RCLCPP_INFO(this->get_logger(), "CAN TX ID: 0x%03X, CAN RX ID: 0x%03X",
                can_tx_id_, can_rx_id_);

    // Subscribe to CAN RX messages (from hardware)
    can_rx_sub_ = this->create_subscription<can_msgs::msg::Frame>(
        "/canbus/rx", 10,
        std::bind(&CameraLiftNode::canRxCallback, this, std::placeholders::_1));

    // Publisher for CAN TX messages (to hardware)
    can_tx_pub_ = this->create_publisher<can_msgs::msg::Frame>("/canbus/tx", 10);

    // Publisher for camera lift status feedback
    feedback_pub_ = this->create_publisher<motion_rover_ros2_msgs::msg::CameraLiftStatus>(
        "camera_lift/status", 10);

    // Action server for camera lift goals
    action_server_ = rclcpp_action::create_server<CameraLiftAction>(
        this,
        "camera_lift",
        std::bind(&CameraLiftNode::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
        std::bind(&CameraLiftNode::handle_cancel, this, std::placeholders::_1),
        std::bind(&CameraLiftNode::handle_accepted, this, std::placeholders::_1)
    );

    // Topic subscriber for UI-based height commands
    height_cmd_sub_ = this->create_subscription<std_msgs::msg::Float32>(
        "camera_lift/target_height", 10,
        std::bind(&CameraLiftNode::topic_height_callback, this, std::placeholders::_1)
    );

    // Timer for the control loop (periodic feedback and command sending)
    control_timer_ = this->create_wall_timer(
        std::chrono::duration<double>(1.0 / control_rate_),
        std::bind(&CameraLiftNode::control_loop, this)
    );

}

/**
 * @brief Declare ROS parameters with default values.
 */
void CameraLiftNode::declareParameters()
{
    this->declare_parameter("can_tx_id", 0x120);
    this->declare_parameter("can_rx_id", 0x220);
    this->declare_parameter("max_height", 0.2);
    this->declare_parameter("tolerance", 0.005);
    this->declare_parameter("control_rate", 10.0);
}

/**
 * @brief Load parameters from the ROS parameter server.
 */
void CameraLiftNode::loadParameters()
{
    int tx_id, rx_id;
    this->get_parameter("can_tx_id", tx_id);
    this->get_parameter("can_rx_id", rx_id);
    this->get_parameter("max_height", max_height_);
    this->get_parameter("tolerance", tolerance_);
    this->get_parameter("control_rate", control_rate_);

    can_tx_id_ = static_cast<uint32_t>(tx_id);
    can_rx_id_ = static_cast<uint32_t>(rx_id);
}

/**
 * @brief Validate loaded parameters and reset to defaults if invalid.
 */
void CameraLiftNode::validateParameters()
{
    if (can_tx_id_ == 0 || can_tx_id_ > 0x7FF) {
        RCLCPP_WARN(this->get_logger(), "Invalid CAN TX ID: 0x%X. Reset to 0x120", can_tx_id_);
        can_tx_id_ = 0x120;
    }
    if (can_rx_id_ == 0 || can_rx_id_ > 0x7FF) {
        RCLCPP_WARN(this->get_logger(), "Invalid CAN RX ID: 0x%X. Reset to 0x220", can_rx_id_);
        can_rx_id_ = 0x220;
    }
    if (max_height_ <= 0.0) {
        RCLCPP_WARN(this->get_logger(), "Invalid max_height: %.3f. Reset to 0.2", max_height_);
        max_height_ = 0.2;
    }
    if (tolerance_ <= 0.0) {
        RCLCPP_WARN(this->get_logger(), "Invalid tolerance: %.3f. Reset to 0.005", tolerance_);
        tolerance_ = 0.005;
    }
    if (control_rate_ <= 0.0) {
        RCLCPP_WARN(this->get_logger(), "Invalid control_rate: %.3f. Reset to 10.0", control_rate_);
        control_rate_ = 10.0;
    }
}

/**
 * @brief Handle new action goal requests.
 *
 * Always accept the goal for further validation in handle_accepted.
 *
 * @param[in] uuid The goal UUID.
 * @param[in] goal The goal message.
 * @return Always ACCEPT_AND_EXECUTE.
 */
rclcpp_action::GoalResponse CameraLiftNode::handle_goal(
    const rclcpp_action::GoalUUID&,
    std::shared_ptr<const CameraLiftAction::Goal> /*goal*/)
{
    // Accept all goals; validation occurs in handle_accepted
    return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

/**
 * @brief Handle action goal cancellation requests.
 *
 * @param[in] goal_handle The handle to the goal being cancelled.
 * @return Always ACCEPT.
 */
rclcpp_action::CancelResponse CameraLiftNode::handle_cancel(
    const std::shared_ptr<GoalHandleCameraLift>)
{
    RCLCPP_INFO(this->get_logger(), "Goal cancellation requested");
    return rclcpp_action::CancelResponse::ACCEPT;
}

/**
 * @brief Accept and execute a valid action goal.
 *
 * Validates the requested height, checks for active goals,
 * and sends the height command if valid.
 *
 * @param[in] goal_handle The handle to the accepted goal.
 */
void CameraLiftNode::handle_accepted(const std::shared_ptr<GoalHandleCameraLift> goal_handle)
{
    std::lock_guard<std::mutex> lock(goal_mutex_);
    double height = goal_handle->get_goal()->height;

    // Check for out-of-bounds height
    if (height < 0.0 || height > max_height_) {
        RCLCPP_ERROR(this->get_logger(), "Rejecting goal: height %.3fm invalid (0-%.3fm)", height, max_height_);
        auto result = std::make_shared<CameraLiftAction::Result>();
        result->success = false;
        result->message = "Requested height " + std::to_string(height) +
                          "m is out of bounds (allowed: 0-" + std::to_string(max_height_) + "m)";
        goal_handle->abort(result);
        return;
    }

    // Check for active goal
    if (active_goal_ || topic_goal_active_) {
        RCLCPP_ERROR(this->get_logger(), "Active goal already exists! Rejecting new action goal");
        auto result = std::make_shared<CameraLiftAction::Result>();
        result->success = false;
        result->message = "Another goal (action or topic) is already active";
        goal_handle->abort(result);
        return;
    }

    // Accept and execute as normal
    active_goal_ = goal_handle;
    send_height_command(height);
}

/**
 * @brief Send a height command to the hardware via CAN.
 *
 * Converts the height from meters to millimeters and
 * sends it in the CAN message payload.
 *
 * @param[in] height_m Target height in meters.
 */
void CameraLiftNode::send_height_command(double height_m)
{
    uint16_t height_mm = static_cast<uint16_t>(std::round(height_m * 1000.0));
    can_msgs::msg::Frame msg;
    msg.id = can_tx_id_;
    msg.dlc = 8; // Always use 8 bytes for CAN payload
    for (int i = 0; i < 8; ++i) msg.data[i] = 0;
    msg.data[0] = static_cast<uint8_t>(height_mm & 0xFF);
    msg.data[1] = static_cast<uint8_t>((height_mm >> 8) & 0xFF);
    can_tx_pub_->publish(msg);
    RCLCPP_DEBUG(this->get_logger(), "Sent height command: %u mm (0x%02X 0x%02X)",
                 height_mm, msg.data[0], msg.data[1]);
}

/**
 * @brief Callback for CAN RX messages.
 *
 * Updates the current height based on hardware feedback and
 * publishes a status message.
 *
 * @param[in] msg The received CAN frame.
 */
void CameraLiftNode::canRxCallback(const can_msgs::msg::Frame::SharedPtr msg)
{
    if (msg->id != can_rx_id_) return;
    if (msg->dlc < 2) {
        RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 1000,
                             "Invalid CAN length: %d (expected >=2)", msg->dlc);
        return;
    }
    uint16_t height_mm = static_cast<uint16_t>(msg->data[0]) |
                         (static_cast<uint16_t>(msg->data[1]) << 8);
    current_height_.store(static_cast<double>(height_mm) / 1000.0);

    // Publish custom status message
    motion_rover_ros2_msgs::msg::CameraLiftStatus status_msg;
    status_msg.height = static_cast<int64_t>(height_mm);
    feedback_pub_->publish(status_msg);
}

/**
 * @brief Callback for topic-based height commands.
 *
 * Validates the requested height and starts a topic-based goal if valid.
 *
 * @param[in] msg The received Float32 message (target height in meters).
 */
void CameraLiftNode::topic_height_callback(const std_msgs::msg::Float32::SharedPtr msg)
{
    double height = static_cast<double>(msg->data);
    if (height < 0.0 || height > max_height_) {
        RCLCPP_WARN(this->get_logger(), "Topic command rejected: height %.3fm invalid (0-%.3fm)", height, max_height_);
        return;
    }
    {
        std::lock_guard<std::mutex> lock(goal_mutex_);
        // If an action goal or topic goal is active, ignore topic command
        if (active_goal_ || topic_goal_active_) {
            RCLCPP_INFO(this->get_logger(), "Topic command ignored: another goal (action or topic) is active");
            return;
        }
        // Set topic goal as active
        topic_goal_active_ = true;
        topic_goal_height_ = height;
    }
    RCLCPP_INFO(this->get_logger(), "Topic command: move to %.3fm", height);
    send_height_command(height);
}

/**
 * @brief Main control loop.
 *
 * Periodically checks and manages both action and topic goals,
 * sending height commands and publishing feedback as needed.
 */
void CameraLiftNode::control_loop()
{
    // Priority: Action goal > Topic goal
    std::shared_ptr<GoalHandleCameraLift> current_goal;
    bool topic_active = false;
    double topic_target = 0.0;
    {
        std::lock_guard<std::mutex> lock(goal_mutex_);
        current_goal = active_goal_;
        topic_active = topic_goal_active_;
        topic_target = topic_goal_height_;
    }
    if (current_goal) {
        const double target = current_goal->get_goal()->height;
        const double current = current_height_.load();
        const double error = std::abs(current - target);

        if (current_goal->is_canceling()) {
            RCLCPP_INFO(this->get_logger(), "Goal canceled at %.3fm", current);
            auto result = std::make_shared<CameraLiftAction::Result>();
            result->success = false;
            result->message = "Goal canceled by client";
            current_goal->canceled(result);
            std::lock_guard<std::mutex> lock(goal_mutex_);
            active_goal_.reset();
            return;
        }

        // Publish feedback
        auto feedback = std::make_shared<CameraLiftAction::Feedback>();
        feedback->current_height = current;
        current_goal->publish_feedback(feedback);

        // Check if goal reached within tolerance
        if (error < tolerance_) {
            RCLCPP_INFO(this->get_logger(), "Goal succeeded: Reached %.3fm (error=%.4fm)", target, error);
            auto result = std::make_shared<CameraLiftAction::Result>();
            result->success = true;
            result->message = "Target height reached";
            current_goal->succeed(result);
            std::lock_guard<std::mutex> lock(goal_mutex_);
            active_goal_.reset();
        } else {
            send_height_command(target);
        }
        return;
    }

    // Handle topic-based goal if no action goal is active
    if (topic_active) {
        double current = current_height_.load();
        double error = std::abs(current - topic_target);

        // Check if goal reached
        if (error < tolerance_) {
            {
                std::lock_guard<std::mutex> lock(goal_mutex_);
                topic_goal_active_ = false;
            }
            RCLCPP_INFO(this->get_logger(), "Topic goal reached: %.3fm", topic_target);
        } else {
            send_height_command(topic_target);
        }
    }
}

/**
 * @brief Main entry point.
 *
 * Initializes and spins the CameraLiftNode.
 */
int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CameraLiftNode>());
    rclcpp::shutdown();
    return 0;
}
