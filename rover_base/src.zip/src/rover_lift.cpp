/**
 * @file rover_lift_node.cpp
 * @brief ROS2 node for rover lift control via CAN bus.
 */

#include "motion_base/rover_lift_node.hpp"
#include <cmath>
#include <sstream>

/**
 * @class GoalActiveGuard
 * @brief RAII helper to manage the command_in_progress_ flag.
 */
GoalActiveGuard::GoalActiveGuard(std::atomic<bool>& flag) : flag_(flag) { flag_ = true; }

GoalActiveGuard::~GoalActiveGuard() { flag_ = false; }

/**
 * @brief Construct the RoverLiftNode, initialize parameters, publishers, and subscriptions.
 */
RoverLiftNode::RoverLiftNode() : Node("rover_lift_action_server") {
    declareParameters();
    loadParameters();
    validateParameters();
    RCLCPP_INFO(this->get_logger(), "Parameter 'height_tolerance' loaded with value: %f", height_tolerance_);
    RCLCPP_INFO(this->get_logger(), "Node '%s' has been initialized.", this->get_name());

    auto now = this->now();
    for (size_t i = 0; i < NUM_LIFTS; ++i) {
        lift_heights_[i] = 0.0;
        lift_last_update_times_[i] = now;
    }

    can_tx_pub_ = this->create_publisher<can_msgs::msg::Frame>("/canbus/tx", 10);
    lift_status_pub_ = this->create_publisher<motion_rover_ros2_msgs::msg::RoverLiftStatus>("rover_lift/status", 10);

    can_rx_sub_ = this->create_subscription<can_msgs::msg::Frame>(
        "/canbus/rx", 10,
        [this](const can_msgs::msg::Frame::SharedPtr msg) {
            this->canRxCallback(msg);
        });

    lift_command_sub_ = this->create_subscription<std_msgs::msg::Float64>(
        "rover_lift/target_height", 10,
        [this](const std_msgs::msg::Float64::SharedPtr msg) {
            this->handleLiftCommand(msg->data);
        });

    action_server_ = rclcpp_action::create_server<RoverLiftAction>(
        this,
        "rover_lift",
        std::bind(&RoverLiftNode::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
        std::bind(&RoverLiftNode::handle_cancel, this, std::placeholders::_1),
        std::bind(&RoverLiftNode::handle_accepted, this, std::placeholders::_1));
}

/**
 * @brief Declare all configurable ROS2 parameters.
 */
void RoverLiftNode::declareParameters() {
    this->declare_parameter("can_tx_id", 0x110);
    this->declare_parameter("can_rx_base_id", 0x210);
    this->declare_parameter("max_height", 0.16);
    this->declare_parameter("min_height", 0.0);
    this->declare_parameter("movement_timeout", 30.0);
    this->declare_parameter("height_tolerance", 0.0001);
    this->declare_parameter("default_speed", 10.0);
}

/**
 * @brief Load parameters from the ROS2 parameter server.
 */
void RoverLiftNode::loadParameters() {
    this->get_parameter("can_tx_id", can_tx_id_);
    this->get_parameter("can_rx_base_id", can_rx_base_id_);
    this->get_parameter("max_height", max_height_);
    this->get_parameter("min_height", min_height_);
    this->get_parameter("movement_timeout", movement_timeout_);
    this->get_parameter("height_tolerance", height_tolerance_);
    this->get_parameter("default_speed", default_speed_);
}

/**
 * @brief Validate loaded parameters.
 * @throws std::runtime_error if any parameter is invalid.
 */
void RoverLiftNode::validateParameters() {
    if (max_height_ <= min_height_) throw std::runtime_error("max_height must be > min_height");
    if (height_tolerance_ <= 0.0) throw std::runtime_error("height_tolerance must be positive");
    if (default_speed_ <= 0.0) throw std::runtime_error("default_speed must be positive");
    if (movement_timeout_ <= 0.0) throw std::runtime_error("movement_timeout must be positive");
}

/**
 * @brief Check if a new command can be accepted.
 * @return True if no command is in progress or the last command is finished.
 */
bool RoverLiftNode::canAcceptNewCommand() {
    std::lock_guard<std::mutex> lock(command_mutex_);
    double current_avg = getAverageHeight();
    return !command_in_progress_ || std::abs(current_avg - last_commanded_height_) <= height_tolerance_;
}

/**
 * @brief Mark command as finished if the target height is reached.
 */
void RoverLiftNode::finishCommandIfArrived() {
    std::lock_guard<std::mutex> lock(command_mutex_);
    double current_avg = getAverageHeight();
    if (command_in_progress_ && std::abs(current_avg - last_commanded_height_) <= height_tolerance_) {
        command_in_progress_ = false;
    }
}

/**
 * @brief Handle new action goal requests.
 * @param uuid The unique identifier for the goal.
 * @param goal The goal message.
 * @return Goal response (accept or reject).
 */
rclcpp_action::GoalResponse RoverLiftNode::handle_goal(const rclcpp_action::GoalUUID&, std::shared_ptr<const RoverLiftAction::Goal> goal) {
    (void)goal;
    return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

/**
 * @brief Handle action goal cancellation requests.
 * @param goal_handle The handle to the goal.
 * @return Cancel response (accept or reject).
 */
rclcpp_action::CancelResponse RoverLiftNode::handle_cancel(const std::shared_ptr<GoalHandleRoverLift>) {
    return rclcpp_action::CancelResponse::ACCEPT;
}

/**
 * @brief Handle accepted action goals.
 * @param goal_handle The handle to the accepted goal.
 */
void RoverLiftNode::handle_accepted(const std::shared_ptr<GoalHandleRoverLift> goal_handle) {
    std::thread{&RoverLiftNode::execute, this, goal_handle}.detach();
}

/**
 * @brief Execute the lift action.
 * @param goal_handle The handle to the action goal.
 */
void RoverLiftNode::execute(const std::shared_ptr<GoalHandleRoverLift> goal_handle) {
    auto result = std::make_shared<RoverLiftAction::Result>();
    auto feedback = std::make_shared<RoverLiftAction::Feedback>();

    double target_height = goal_handle->get_goal()->height;

    {
        std::lock_guard<std::mutex> lock(command_mutex_);
        double current_avg = getAverageHeight();
        if (command_in_progress_ && std::abs(current_avg - last_commanded_height_) > height_tolerance_) {
            result->success = false;
            result->message = "Lift is still moving to previous commanded height. Try again later.";
            goal_handle->abort(result);
            return;
        }
        if (target_height >= max_height_ || target_height < min_height_) {
            result->success = false;
            std::ostringstream oss;
            oss << "Requested height " << target_height << " out of range ("
                << min_height_ << " < height < " << max_height_ << ")";
            result->message = oss.str();
            goal_handle->abort(result);
            return;
        }
        command_in_progress_ = true;
        last_commanded_height_ = target_height;
    }

    GoalActiveGuard guard(command_in_progress_);

    uint16_t height_mm = static_cast<uint16_t>(std::round(target_height * 1000.0));
    uint16_t speed_mmps = static_cast<uint16_t>(default_speed_);

    can_msgs::msg::Frame can_msg;
    can_msg.id = can_tx_id_;
    can_msg.is_extended = false;
    can_msg.is_rtr = false;
    can_msg.is_error = false;
    can_msg.dlc = 8;
    can_msg.data[0] = static_cast<uint8_t>(height_mm & 0xFF);
    can_msg.data[1] = static_cast<uint8_t>((height_mm >> 8) & 0xFF);
    can_msg.data[2] = static_cast<uint8_t>(speed_mmps & 0xFF);
    can_msg.data[3] = static_cast<uint8_t>((speed_mmps >> 8) & 0xFF);
    for (int i = 4; i < 8; ++i) can_msg.data[i] = 0x00;

    can_tx_pub_->publish(can_msg);

    rclcpp::Rate loop_rate(10);
    auto start_time = this->now();

    while (rclcpp::ok() && !goal_handle->is_canceling()) {
        double current_avg = getAverageHeight();
        double error = std::abs(current_avg - target_height);

        feedback->current_height = current_avg;
        goal_handle->publish_feedback(feedback);

        if (error <= height_tolerance_) {
            result->success = true;
            result->message = "Target height reached.";
            goal_handle->succeed(result);
            finishCommandIfArrived();
            return;
        }

        if ((this->now() - start_time).seconds() > movement_timeout_) {
            result->success = false;
            result->message = "Movement timeout reached.";
            goal_handle->abort(result);
            finishCommandIfArrived();
            return;
        }

        loop_rate.sleep();
    }

    if (goal_handle->is_canceling()) {
        result->success = false;
        result->message = "Goal canceled by client.";
        goal_handle->canceled(result);
        finishCommandIfArrived();
    }
}

/**
 * @brief Handle direct height commands from a topic.
 * @param height The target lift height in meters.
 */
void RoverLiftNode::handleLiftCommand(double height) {
    std::lock_guard<std::mutex> lock(command_mutex_);
    double current_avg = getAverageHeight();
    if (command_in_progress_ && std::abs(current_avg - last_commanded_height_) > height_tolerance_) {
        RCLCPP_WARN(this->get_logger(), "Lift is still moving to previous commanded height. Ignoring new topic command.");
        return;
    }
    if (height < min_height_ || height > max_height_) {
        RCLCPP_WARN(this->get_logger(), "Topic command out of range: %.3f m (%.3f-%.3f)", height, min_height_, max_height_);
        return;
    }
    command_in_progress_ = true;
    last_commanded_height_ = height;
    uint16_t height_mm = static_cast<uint16_t>(std::round(height * 1000.0));
    uint16_t speed_mmps = static_cast<uint16_t>(default_speed_);
    can_msgs::msg::Frame can_msg;
    can_msg.id = can_tx_id_;
    can_msg.is_extended = false;
    can_msg.is_rtr = false;
    can_msg.is_error = false;
    can_msg.dlc = 8;
    can_msg.data[0] = static_cast<uint8_t>(height_mm & 0xFF);
    can_msg.data[1] = static_cast<uint8_t>((height_mm >> 8) & 0xFF);
    can_msg.data[2] = static_cast<uint8_t>(speed_mmps & 0xFF);
    can_msg.data[3] = static_cast<uint8_t>((speed_mmps >> 8) & 0xFF);
    for (int i = 4; i < 8; ++i) can_msg.data[i] = 0x00;
    can_tx_pub_->publish(can_msg);
    RCLCPP_INFO(this->get_logger(), "Lift topic command: height=%.3f m", height);
}

/**
 * @brief Compute the average lift height from all lifts.
 * @return The average height in meters.
 */
double RoverLiftNode::getAverageHeight() {
    std::lock_guard<std::mutex> lock(height_mutex_);
    double sum = 0.0;
    for (size_t i = 0; i < NUM_LIFTS; ++i) {
        double h = lift_heights_[i];
        if (h < 0.0) h = 0.0;
        sum += h;
    }
    return sum / static_cast<double>(NUM_LIFTS);
}

/**
 * @brief Callback for incoming CAN bus messages.
 * @param msg The received CAN frame.
 */
void RoverLiftNode::canRxCallback(const can_msgs::msg::Frame::SharedPtr msg) {
    if (msg->id < can_rx_base_id_ || msg->id >= can_rx_base_id_ + NUM_LIFTS) return;
    if (msg->dlc != 8) return;

    size_t index = msg->id - can_rx_base_id_;
    uint16_t height_hundredths_mm = (static_cast<uint16_t>(msg->data[1]) << 8) | msg->data[0];
    double height_m = static_cast<double>(height_hundredths_mm) * 0.00001;

    {
        std::lock_guard<std::mutex> lock(height_mutex_);
        lift_heights_[index] = height_m;
    }
    {
        std::lock_guard<std::mutex> lock(last_update_mutex_);
        lift_last_update_times_[index] = this->now();
    }

    publishLiftStatus();
    finishCommandIfArrived();
}

/**
 * @brief Publish the current lift status.
 */
void RoverLiftNode::publishLiftStatus() {
    auto status_msg = std::make_unique<motion_rover_ros2_msgs::msg::RoverLiftStatus>();
    auto now = this->now();
    for (size_t i = 0; i < NUM_LIFTS; ++i) {
        motion_rover_ros2_msgs::msg::LiftData data;
        {
            std::lock_guard<std::mutex> lock(height_mutex_);
            double h = lift_heights_[i];
            data.height = h < 0.0 ? 0.0 : h;
        }
        {
            std::lock_guard<std::mutex> lock(last_update_mutex_);
            data.read_time_lapse = (now - lift_last_update_times_[i]).seconds();
        }
        data.id = static_cast<uint8_t>(i);
        status_msg->data.push_back(data);
    }
    lift_status_pub_->publish(std::move(status_msg));
}

/**
 * @brief Main entry point for the rover lift node.
 * @param argc Argument count.
 * @param argv Argument vector.
 * @return Exit code.
 */
int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<RoverLiftNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
